require('dotenv').config();
const express=require('express');
const app = express();
const mongoose = require('mongoose');
const cors=require('cors');
const morgan=require('morgan');
const hbs=require('hbs');
const path=require('path');
hbs.registerPartials(path.join(__dirname,'views/partials'));

const LinkPressRouter=require("./api/v1/routes/linkpress");

app.use(morgan('dev'));
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({
    extended:false
}));
app.use(express.static('public'));



mongoose.connect("mongodb+srv://simon:yaron123@cluster0.aas0e.mongodb.net/LinkPress",{useNewUrlParser:true,useUnifiedTopology:true}).then(()=>{console.log('mongo db connected')});
app.set('views', path.join(__dirname,'views'));//מחילה את מסתרפגים שלי
//מנואה תצוגות של תפלאתים
app.set('view engine','hbs');
app.use("/press",LinkPressRouter);
app.get('/all',(req,res)=>{
    res.render('AllUrls');
})
app.get('/',(req,res)=>{
    res.render('index',{welcome:'hello from raz'});
});


app.all("*",(req,res)=>{
    res.status(404).json({msg:"404 Page not Fount"})
    });



    

module.exports=app;