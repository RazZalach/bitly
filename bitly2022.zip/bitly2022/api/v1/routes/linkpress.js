const router = require('express').Router();
const {LogLinkId,RegLink,AllUrl}=require("../controller/linkpress");

router.post("/",RegLink);
router.get("/:Lid",LogLinkId);
router.get("/",AllUrl);

module.exports=router;