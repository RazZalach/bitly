const mongoose=require("mongoose");
const Link=require("../models/linkpress");
var generator = require('generate-password');
function GetRandomString(len){
    str="";
    index=0;
    chars="abcdefghijklmnopqrstuvwxyz0123456789";
    for(let i=0;i<len;i++){
        index=Math.floor(Math.random() * chars.length );
        str+=chars[index];
    }
    return str;

}
module.exports={
    LogLinkId:(req,res)=>{
      
        Link.findOne({Urlres:""+req.params.Lid}).then((rows)=>{
            console.log(req.params.Lid);
            if(rows.length == 0)
            {
                return res.status(401).json({msg:"The link Not Found"})
            }else{
               
                return res.redirect(rows.Url);
            }

        });
    },
AllUrl:(req,res)=>{
Link.find().sort({_id:-1}).limit(Math.random()*5 +5).then((rows)=>{
    console.log(rows.toString());
    return res.status(200).json(rows);
    ;
})
},


    RegLink:(req,res)=>{
        const {Url}=req.body;
                var short = GetRandomString(8);
                if(Url==null){
                    console.log('zain!!!');
                }
                const lk = new Link({
                    _id:new mongoose.Types.ObjectId(),
                    Url:Url,
                    Urlres:short
                });
                lk.save().then(()=>{
                    return res.status(200).json({link:short});
                }).catch((error)=>{
                    return res.status(505).json({error});
                });              

    }
};