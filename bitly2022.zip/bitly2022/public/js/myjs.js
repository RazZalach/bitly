fetch('/press',{method:'GET'}).then((res)=>{
    return res.json()}).then((data)=>{
     var tbl=document.getElementById('mytable');
     var tbl2=document.getElementById('mytable2');
    for(let i=0;i<data.length;i++){ 
      var row=tbl.insertRow();
     var cell=row.insertCell(); 
     var row2=tbl2.insertRow();
     var cell2=row2.insertCell();
        cell.innerHTML=data[i].Urlres;
        cell2.innerHTML=data[i].Url;
     
    }
 });


 function myfunc(){
   
    const Url= document.getElementById("url").value;  
fetch('/press', {
   method: 'POST',
   body: new URLSearchParams({
     Url:Url      
   })
 }).then((res)=>{
   return res.json()}).then((data)=>{
     let uri=window.location+'press/'+data.link;
     // alert(uri);
      document.getElementById("ShortUrl").innerHTML = uri;
      document.getElementById("ShortUrl").href = uri;
      })
    

 
       
  }

